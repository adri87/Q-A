package es.upm.dit.gsi.sojason.beans;

/**
 * This defines the different means of transport.
 * @author gsi.dit.upm.es
 */
public enum TravelType {
	flight,
	train,
	coach, 
	bus
}
