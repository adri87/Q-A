package es.upm.dit.gsi.sojason.beans;
import jason.asSyntax.Literal;

import java.util.List;

/**
 * @author miguel
 *
 */
public interface Perceptable {

	public List<Literal> toPercepts();
	
}
