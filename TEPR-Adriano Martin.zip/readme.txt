Para que el cliente de chrome te devuelva el viaje más barato a un determinado destino se le debe escribir una frase del estilo:

	".....4 personas... el 3 de julio de 2012..... de madrid ... a barcelona.."

El orden en el que se pongan estos textos es indiferente e incluso reconoce si no hemos puesto alguno de estos parámetros y nos los irá pidiendo.

Así mismo se ha incluido un diccionario months a la gramática de unitex y a su grafo. Con la mecánica correspondiente para tratarlo y no tener que poner 
los nombres, hablando en un lenguaje más natural.

Se no hay viajes disponibles para lo que ha solicitado el usario, el cliente se lo comunicará.

Así mismo seha incluido un filtrado según tarifa elegida por el usuario (con nuevo diccionario fares y su inclusión en el grafo). Se han comprobado individualemente
cada uno de los planes, sin embargo debido a un error sin detectar en las reglas se ha dejado toda esta parte comentada ya que entra siempre en el primero que se 
encuentra en la lista. 
Sin embargo, esta disponible para ser evaluado como se crea convenientemente, siendo la parte del código comentada con //.

La frase de inicio del cliente chrome ha sido cambiada.
