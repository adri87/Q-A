package com.sun.java.swing.plaf.motif.resources;

import java.util.ListResourceBundle;

public final class motif_zh_TW extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "FileChooser.acceptAllFileFilterText", "*" },
            { "FileChooser.cancelButtonText", "\u53D6\u6D88" },
            { "FileChooser.cancelButtonToolTipText", "\u4E2D\u6B62\u6A94\u6848\u9078\u64C7\u5668\u5C0D\u8A71\u65B9\u584A\u3002" },
            { "FileChooser.enterFileNameLabelText", "\u8F38\u5165\u6A94\u6848\u540D\u7A31:" },
            { "FileChooser.enterFolderNameLabelText", "\u8F38\u5165\u8CC7\u6599\u593E\u540D\u7A31:" },
            { "FileChooser.filesLabelText", "\u6A94\u6848" },
            { "FileChooser.filterLabelText", "\u7BE9\u9078" },
            { "FileChooser.foldersLabelText", "\u8CC7\u6599\u593E" },
            { "FileChooser.helpButtonText", "\u8AAA\u660E" },
            { "FileChooser.helpButtonToolTipText", "\u300C\u6A94\u6848\u9078\u64C7\u5668\u300D\u8AAA\u660E\u3002" },
            { "FileChooser.openButtonText", "\u78BA\u5B9A" },
            { "FileChooser.openButtonToolTipText", "\u958B\u555F\u9078\u53D6\u7684\u6A94\u6848\u3002" },
            { "FileChooser.openDialogTitleText", "\u958B\u555F" },
            { "FileChooser.pathLabelText", "\u8F38\u5165\u8DEF\u5F91\u6216\u8CC7\u6599\u593E\u540D\u7A31:" },
            { "FileChooser.saveButtonText", "\u5132\u5B58" },
            { "FileChooser.saveButtonToolTipText", "\u5132\u5B58\u9078\u53D6\u7684\u6A94\u6848\u3002" },
            { "FileChooser.saveDialogTitleText", "\u5132\u5B58" },
            { "FileChooser.updateButtonText", "\u66F4\u65B0" },
            { "FileChooser.updateButtonToolTipText", "\u66F4\u65B0\u76EE\u9304\u6E05\u55AE\u3002" },
        };
    }
}
