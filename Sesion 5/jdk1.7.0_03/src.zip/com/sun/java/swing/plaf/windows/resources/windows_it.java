package com.sun.java.swing.plaf.windows.resources;

import java.util.ListResourceBundle;

public final class windows_it extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "FileChooser.detailsViewActionLabelText", "Dettagli" },
            { "FileChooser.detailsViewButtonAccessibleName", "Dettagli" },
            { "FileChooser.detailsViewButtonToolTipText", "Dettagli" },
            { "FileChooser.fileAttrHeaderText", "Attributi" },
            { "FileChooser.fileDateHeaderText", "Modificato" },
            { "FileChooser.fileNameHeaderText", "Nome" },
            { "FileChooser.fileNameLabelText", "Nome file:" },
            { "FileChooser.fileSizeHeaderText", "Dimensioni" },
            { "FileChooser.fileTypeHeaderText", "Tipo" },
            { "FileChooser.filesOfTypeLabelText", "Tipo file:" },
            { "FileChooser.folderNameLabelText", "Nome della cartella:" },
            { "FileChooser.homeFolderAccessibleName", "Home" },
            { "FileChooser.homeFolderToolTipText", "Home" },
            { "FileChooser.listViewActionLabelText", "Lista" },
            { "FileChooser.listViewButtonAccessibleName", "Lista" },
            { "FileChooser.listViewButtonToolTipText", "Lista" },
            { "FileChooser.lookInLabelText", "Cerca in:" },
            { "FileChooser.newFolderAccessibleName", "Nuova cartella" },
            { "FileChooser.newFolderActionLabelText", "Nuova cartella" },
            { "FileChooser.newFolderToolTipText", "Crea nuova cartella" },
            { "FileChooser.refreshActionLabelText", "Aggiorna" },
            { "FileChooser.saveInLabelText", "Salva in:" },
            { "FileChooser.upFolderAccessibleName", "Superiore" },
            { "FileChooser.upFolderToolTipText", "Cartella superiore" },
            { "FileChooser.viewMenuButtonAccessibleName", "Visualizza menu" },
            { "FileChooser.viewMenuButtonToolTipText", "Visualizza menu" },
            { "FileChooser.viewMenuLabelText", "Visualizza" },
        };
    }
}
