package com.sun.java.swing.plaf.windows.resources;

import java.util.ListResourceBundle;

public final class windows_ko extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "FileChooser.detailsViewActionLabelText", "\uC138\uBD80 \uC815\uBCF4" },
            { "FileChooser.detailsViewButtonAccessibleName", "\uC138\uBD80 \uC815\uBCF4" },
            { "FileChooser.detailsViewButtonToolTipText", "\uC138\uBD80 \uC815\uBCF4" },
            { "FileChooser.fileAttrHeaderText", "\uC18D\uC131" },
            { "FileChooser.fileDateHeaderText", "\uC218\uC815 \uB0A0\uC9DC" },
            { "FileChooser.fileNameHeaderText", "\uC774\uB984" },
            { "FileChooser.fileNameLabelText", "\uD30C\uC77C \uC774\uB984:" },
            { "FileChooser.fileSizeHeaderText", "\uD06C\uAE30" },
            { "FileChooser.fileTypeHeaderText", "\uC720\uD615" },
            { "FileChooser.filesOfTypeLabelText", "\uD30C\uC77C \uC720\uD615:" },
            { "FileChooser.folderNameLabelText", "\uD3F4\uB354 \uC774\uB984:" },
            { "FileChooser.homeFolderAccessibleName", "\uD648" },
            { "FileChooser.homeFolderToolTipText", "\uD648" },
            { "FileChooser.listViewActionLabelText", "\uBAA9\uB85D" },
            { "FileChooser.listViewButtonAccessibleName", "\uBAA9\uB85D" },
            { "FileChooser.listViewButtonToolTipText", "\uBAA9\uB85D" },
            { "FileChooser.lookInLabelText", "\uAC80\uC0C9 \uC704\uCE58:" },
            { "FileChooser.newFolderAccessibleName", "\uC0C8 \uD3F4\uB354" },
            { "FileChooser.newFolderActionLabelText", "\uC0C8 \uD3F4\uB354" },
            { "FileChooser.newFolderToolTipText", "\uC0C8 \uD3F4\uB354 \uC0DD\uC131" },
            { "FileChooser.refreshActionLabelText", "\uC0C8\uB85C \uACE0\uCE68" },
            { "FileChooser.saveInLabelText", "\uC800\uC7A5 \uC704\uCE58:" },
            { "FileChooser.upFolderAccessibleName", "\uC704\uB85C" },
            { "FileChooser.upFolderToolTipText", "\uD55C \uB808\uBCA8 \uC704\uB85C" },
            { "FileChooser.viewMenuButtonAccessibleName", "\uBCF4\uAE30 \uBA54\uB274" },
            { "FileChooser.viewMenuButtonToolTipText", "\uBCF4\uAE30 \uBA54\uB274" },
            { "FileChooser.viewMenuLabelText", "\uBCF4\uAE30" },
        };
    }
}
