package com.sun.java.swing.plaf.windows.resources;

import java.util.ListResourceBundle;

public final class windows_ja extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "FileChooser.detailsViewActionLabelText", "\u8A73\u7D30" },
            { "FileChooser.detailsViewButtonAccessibleName", "\u8A73\u7D30" },
            { "FileChooser.detailsViewButtonToolTipText", "\u8A73\u7D30" },
            { "FileChooser.fileAttrHeaderText", "\u5C5E\u6027" },
            { "FileChooser.fileDateHeaderText", "\u4FEE\u6B63\u65E5" },
            { "FileChooser.fileNameHeaderText", "\u540D\u524D" },
            { "FileChooser.fileNameLabelText", "\u30D5\u30A1\u30A4\u30EB\u540D:" },
            { "FileChooser.fileSizeHeaderText", "\u30B5\u30A4\u30BA" },
            { "FileChooser.fileTypeHeaderText", "\u30BF\u30A4\u30D7" },
            { "FileChooser.filesOfTypeLabelText", "\u30D5\u30A1\u30A4\u30EB\u306E\u30BF\u30A4\u30D7:" },
            { "FileChooser.folderNameLabelText", "\u30D5\u30A9\u30EB\u30C0\u540D:" },
            { "FileChooser.homeFolderAccessibleName", "\u30DB\u30FC\u30E0" },
            { "FileChooser.homeFolderToolTipText", "\u30DB\u30FC\u30E0" },
            { "FileChooser.listViewActionLabelText", "\u30EA\u30B9\u30C8" },
            { "FileChooser.listViewButtonAccessibleName", "\u30EA\u30B9\u30C8" },
            { "FileChooser.listViewButtonToolTipText", "\u30EA\u30B9\u30C8" },
            { "FileChooser.lookInLabelText", "\u53C2\u7167:" },
            { "FileChooser.newFolderAccessibleName", "\u65B0\u898F\u30D5\u30A9\u30EB\u30C0" },
            { "FileChooser.newFolderActionLabelText", "\u65B0\u898F\u30D5\u30A9\u30EB\u30C0" },
            { "FileChooser.newFolderToolTipText", "\u65B0\u898F\u30D5\u30A9\u30EB\u30C0\u306E\u4F5C\u6210" },
            { "FileChooser.refreshActionLabelText", "\u30EA\u30D5\u30EC\u30C3\u30B7\u30E5" },
            { "FileChooser.saveInLabelText", "\u4FDD\u5B58:" },
            { "FileChooser.upFolderAccessibleName", "\u4E0A\u3078" },
            { "FileChooser.upFolderToolTipText", "1\u30EC\u30D9\u30EB\u4E0A\u3078" },
            { "FileChooser.viewMenuButtonAccessibleName", "\u8868\u793A\u30E1\u30CB\u30E5\u30FC" },
            { "FileChooser.viewMenuButtonToolTipText", "\u8868\u793A\u30E1\u30CB\u30E5\u30FC" },
            { "FileChooser.viewMenuLabelText", "\u8868\u793A" },
        };
    }
}
