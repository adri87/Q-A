package com.sun.java.swing.plaf.windows.resources;

import java.util.ListResourceBundle;

public final class windows_pt_BR extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "FileChooser.detailsViewActionLabelText", "Detalhes" },
            { "FileChooser.detailsViewButtonAccessibleName", "Detalhes" },
            { "FileChooser.detailsViewButtonToolTipText", "Detalhes" },
            { "FileChooser.fileAttrHeaderText", "Atributos" },
            { "FileChooser.fileDateHeaderText", "Modificado" },
            { "FileChooser.fileNameHeaderText", "Nome" },
            { "FileChooser.fileNameLabelText", "Nome do arquivo:" },
            { "FileChooser.fileSizeHeaderText", "Tamanho" },
            { "FileChooser.fileTypeHeaderText", "Tipo" },
            { "FileChooser.filesOfTypeLabelText", "Arquivos do tipo:" },
            { "FileChooser.folderNameLabelText", "Nome da pasta:" },
            { "FileChooser.homeFolderAccessibleName", "In\u00EDcio" },
            { "FileChooser.homeFolderToolTipText", "In\u00EDcio" },
            { "FileChooser.listViewActionLabelText", "Lista" },
            { "FileChooser.listViewButtonAccessibleName", "Lista" },
            { "FileChooser.listViewButtonToolTipText", "Lista" },
            { "FileChooser.lookInLabelText", "Consultar em:" },
            { "FileChooser.newFolderAccessibleName", "Nova Pasta" },
            { "FileChooser.newFolderActionLabelText", "Nova Pasta" },
            { "FileChooser.newFolderToolTipText", "Criar Nova Pasta" },
            { "FileChooser.refreshActionLabelText", "Atualizar" },
            { "FileChooser.saveInLabelText", "Salvar em:" },
            { "FileChooser.upFolderAccessibleName", "Acima" },
            { "FileChooser.upFolderToolTipText", "Um N\u00EDvel Acima" },
            { "FileChooser.viewMenuButtonAccessibleName", "Exibir Menu" },
            { "FileChooser.viewMenuButtonToolTipText", "Exibir Menu" },
            { "FileChooser.viewMenuLabelText", "Exibir" },
        };
    }
}
