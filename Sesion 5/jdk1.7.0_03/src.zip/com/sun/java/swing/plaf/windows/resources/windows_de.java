package com.sun.java.swing.plaf.windows.resources;

import java.util.ListResourceBundle;

public final class windows_de extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "FileChooser.detailsViewActionLabelText", "Details" },
            { "FileChooser.detailsViewButtonAccessibleName", "Details" },
            { "FileChooser.detailsViewButtonToolTipText", "Details" },
            { "FileChooser.fileAttrHeaderText", "Attribute" },
            { "FileChooser.fileDateHeaderText", "Ge\u00E4ndert" },
            { "FileChooser.fileNameHeaderText", "Name" },
            { "FileChooser.fileNameLabelText", "Dateiname:" },
            { "FileChooser.fileSizeHeaderText", "Gr\u00F6\u00DFe" },
            { "FileChooser.fileTypeHeaderText", "Typ" },
            { "FileChooser.filesOfTypeLabelText", "Dateityp:" },
            { "FileChooser.folderNameLabelText", "Ordnername:" },
            { "FileChooser.homeFolderAccessibleName", "Home" },
            { "FileChooser.homeFolderToolTipText", "Home" },
            { "FileChooser.listViewActionLabelText", "Liste" },
            { "FileChooser.listViewButtonAccessibleName", "Liste" },
            { "FileChooser.listViewButtonToolTipText", "Liste" },
            { "FileChooser.lookInLabelText", "Suchen in:" },
            { "FileChooser.newFolderAccessibleName", "Neuer Ordner" },
            { "FileChooser.newFolderActionLabelText", "Neuer Ordner" },
            { "FileChooser.newFolderToolTipText", "Neuen Ordner erstellen" },
            { "FileChooser.refreshActionLabelText", "Aktualisieren" },
            { "FileChooser.saveInLabelText", "Speichern in:" },
            { "FileChooser.upFolderAccessibleName", "Nach oben" },
            { "FileChooser.upFolderToolTipText", "Eine Ebene h\u00F6her" },
            { "FileChooser.viewMenuButtonAccessibleName", "Ansichtsmen\u00FC" },
            { "FileChooser.viewMenuButtonToolTipText", "Ansichtsmen\u00FC" },
            { "FileChooser.viewMenuLabelText", "Ansicht" },
        };
    }
}
