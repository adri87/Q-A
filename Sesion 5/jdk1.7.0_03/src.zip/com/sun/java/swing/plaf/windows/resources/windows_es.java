package com.sun.java.swing.plaf.windows.resources;

import java.util.ListResourceBundle;

public final class windows_es extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "FileChooser.detailsViewActionLabelText", "Detalles" },
            { "FileChooser.detailsViewButtonAccessibleName", "Detalles" },
            { "FileChooser.detailsViewButtonToolTipText", "Detalles" },
            { "FileChooser.fileAttrHeaderText", "Atributos" },
            { "FileChooser.fileDateHeaderText", "Modificado" },
            { "FileChooser.fileNameHeaderText", "Nombre" },
            { "FileChooser.fileNameLabelText", "Nombre de Archivo:" },
            { "FileChooser.fileSizeHeaderText", "Tama\u00F1o" },
            { "FileChooser.fileTypeHeaderText", "Tipo" },
            { "FileChooser.filesOfTypeLabelText", "Archivos de Tipo:" },
            { "FileChooser.folderNameLabelText", "Nombre de la Carpeta:" },
            { "FileChooser.homeFolderAccessibleName", "Inicio" },
            { "FileChooser.homeFolderToolTipText", "Inicio" },
            { "FileChooser.listViewActionLabelText", "Lista" },
            { "FileChooser.listViewButtonAccessibleName", "Lista" },
            { "FileChooser.listViewButtonToolTipText", "Lista" },
            { "FileChooser.lookInLabelText", "Buscar en:" },
            { "FileChooser.newFolderAccessibleName", "Nueva Carpeta" },
            { "FileChooser.newFolderActionLabelText", "Nueva Carpeta" },
            { "FileChooser.newFolderToolTipText", "Crear Nueva Carpeta" },
            { "FileChooser.refreshActionLabelText", "Refrescar" },
            { "FileChooser.saveInLabelText", "Guardar en:" },
            { "FileChooser.upFolderAccessibleName", "Arriba" },
            { "FileChooser.upFolderToolTipText", "Subir un Nivel" },
            { "FileChooser.viewMenuButtonAccessibleName", "Men\u00FA Ver" },
            { "FileChooser.viewMenuButtonToolTipText", "Men\u00FA Ver" },
            { "FileChooser.viewMenuLabelText", "Ver" },
        };
    }
}
