package com.sun.java.swing.plaf.windows.resources;

import java.util.ListResourceBundle;

public final class windows_zh_HK extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "FileChooser.detailsViewActionLabelText", "\u8A73\u7D30\u8CC7\u8A0A" },
            { "FileChooser.detailsViewButtonAccessibleName", "\u8A73\u7D30\u8CC7\u8A0A" },
            { "FileChooser.detailsViewButtonToolTipText", "\u8A73\u7D30\u8CC7\u8A0A" },
            { "FileChooser.fileAttrHeaderText", "\u5C6C\u6027" },
            { "FileChooser.fileDateHeaderText", "\u4FEE\u6539\u65E5\u671F" },
            { "FileChooser.fileNameHeaderText", "\u540D\u7A31" },
            { "FileChooser.fileNameLabelText", "\u6A94\u6848\u540D\u7A31:" },
            { "FileChooser.fileSizeHeaderText", "\u5927\u5C0F" },
            { "FileChooser.fileTypeHeaderText", "\u985E\u578B" },
            { "FileChooser.filesOfTypeLabelText", "\u6A94\u6848\u985E\u578B:" },
            { "FileChooser.folderNameLabelText", "\u8CC7\u6599\u593E\u540D\u7A31:" },
            { "FileChooser.homeFolderAccessibleName", "\u4E3B\u76EE\u9304" },
            { "FileChooser.homeFolderToolTipText", "\u4E3B\u76EE\u9304" },
            { "FileChooser.listViewActionLabelText", "\u6E05\u55AE" },
            { "FileChooser.listViewButtonAccessibleName", "\u6E05\u55AE" },
            { "FileChooser.listViewButtonToolTipText", "\u6E05\u55AE" },
            { "FileChooser.lookInLabelText", "\u67E5\u8A62:" },
            { "FileChooser.newFolderAccessibleName", "\u65B0\u8CC7\u6599\u593E" },
            { "FileChooser.newFolderActionLabelText", "\u65B0\u8CC7\u6599\u593E" },
            { "FileChooser.newFolderToolTipText", "\u5EFA\u7ACB\u65B0\u8CC7\u6599\u593E" },
            { "FileChooser.refreshActionLabelText", "\u91CD\u65B0\u6574\u7406" },
            { "FileChooser.saveInLabelText", "\u5132\u5B58\u65BC: " },
            { "FileChooser.upFolderAccessibleName", "\u5F80\u4E0A" },
            { "FileChooser.upFolderToolTipText", "\u5F80\u4E0A\u4E00\u5C64" },
            { "FileChooser.viewMenuButtonAccessibleName", "\u6AA2\u8996\u529F\u80FD\u8868" },
            { "FileChooser.viewMenuButtonToolTipText", "\u6AA2\u8996\u529F\u80FD\u8868" },
            { "FileChooser.viewMenuLabelText", "\u6AA2\u8996" },
        };
    }
}
