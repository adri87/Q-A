package com.sun.java.swing.plaf.windows.resources;

import java.util.ListResourceBundle;

public final class windows_zh_CN extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "FileChooser.detailsViewActionLabelText", "\u8BE6\u7EC6\u8D44\u6599" },
            { "FileChooser.detailsViewButtonAccessibleName", "\u8BE6\u7EC6\u8D44\u6599" },
            { "FileChooser.detailsViewButtonToolTipText", "\u8BE6\u7EC6\u8D44\u6599" },
            { "FileChooser.fileAttrHeaderText", "\u5C5E\u6027" },
            { "FileChooser.fileDateHeaderText", "\u4FEE\u6539\u65E5\u671F" },
            { "FileChooser.fileNameHeaderText", "\u540D\u79F0" },
            { "FileChooser.fileNameLabelText", "\u6587\u4EF6\u540D: " },
            { "FileChooser.fileSizeHeaderText", "\u5927\u5C0F" },
            { "FileChooser.fileTypeHeaderText", "\u7C7B\u578B" },
            { "FileChooser.filesOfTypeLabelText", "\u6587\u4EF6\u7C7B\u578B: " },
            { "FileChooser.folderNameLabelText", "\u6587\u4EF6\u5939\u540D: " },
            { "FileChooser.homeFolderAccessibleName", "\u4E3B\u76EE\u5F55" },
            { "FileChooser.homeFolderToolTipText", "\u4E3B\u76EE\u5F55" },
            { "FileChooser.listViewActionLabelText", "\u5217\u8868" },
            { "FileChooser.listViewButtonAccessibleName", "\u5217\u8868" },
            { "FileChooser.listViewButtonToolTipText", "\u5217\u8868" },
            { "FileChooser.lookInLabelText", "\u67E5\u770B: " },
            { "FileChooser.newFolderAccessibleName", "\u65B0\u5EFA\u6587\u4EF6\u5939" },
            { "FileChooser.newFolderActionLabelText", "\u65B0\u5EFA\u6587\u4EF6\u5939" },
            { "FileChooser.newFolderToolTipText", "\u521B\u5EFA\u65B0\u6587\u4EF6\u5939" },
            { "FileChooser.refreshActionLabelText", "\u5237\u65B0" },
            { "FileChooser.saveInLabelText", "\u4FDD\u5B58: " },
            { "FileChooser.upFolderAccessibleName", "\u5411\u4E0A" },
            { "FileChooser.upFolderToolTipText", "\u5411\u4E0A\u4E00\u7EA7" },
            { "FileChooser.viewMenuButtonAccessibleName", "\u67E5\u770B\u83DC\u5355" },
            { "FileChooser.viewMenuButtonToolTipText", "\u67E5\u770B\u83DC\u5355" },
            { "FileChooser.viewMenuLabelText", "\u89C6\u56FE" },
        };
    }
}
