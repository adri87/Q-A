package com.sun.java.swing.plaf.windows.resources;

import java.util.ListResourceBundle;

public final class windows_sv extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "FileChooser.detailsViewActionLabelText", "Detaljer" },
            { "FileChooser.detailsViewButtonAccessibleName", "Detaljer" },
            { "FileChooser.detailsViewButtonToolTipText", "Detaljer" },
            { "FileChooser.fileAttrHeaderText", "Attribut" },
            { "FileChooser.fileDateHeaderText", "\u00C4ndrad" },
            { "FileChooser.fileNameHeaderText", "Namn" },
            { "FileChooser.fileNameLabelText", "Filnamn:" },
            { "FileChooser.fileSizeHeaderText", "Storlek" },
            { "FileChooser.fileTypeHeaderText", "Typ" },
            { "FileChooser.filesOfTypeLabelText", "Filformat:" },
            { "FileChooser.folderNameLabelText", "Mapp:" },
            { "FileChooser.homeFolderAccessibleName", "Hem" },
            { "FileChooser.homeFolderToolTipText", "Hem" },
            { "FileChooser.listViewActionLabelText", "Lista" },
            { "FileChooser.listViewButtonAccessibleName", "Lista" },
            { "FileChooser.listViewButtonToolTipText", "Lista" },
            { "FileChooser.lookInLabelText", "Leta i:" },
            { "FileChooser.newFolderAccessibleName", "Ny mapp" },
            { "FileChooser.newFolderActionLabelText", "Ny mapp" },
            { "FileChooser.newFolderToolTipText", "Skapa ny mapp" },
            { "FileChooser.refreshActionLabelText", "F\u00F6rnya" },
            { "FileChooser.saveInLabelText", "Spara i:" },
            { "FileChooser.upFolderAccessibleName", "Upp" },
            { "FileChooser.upFolderToolTipText", "Upp en niv\u00E5" },
            { "FileChooser.viewMenuButtonAccessibleName", "Menyn Visa" },
            { "FileChooser.viewMenuButtonToolTipText", "Menyn Visa" },
            { "FileChooser.viewMenuLabelText", "Vy" },
        };
    }
}
